$(document).on("pagecreate", function() {
	$("#splahLabel1").slideDown(3000, function() {
		// window.location = 'login.php';
		window.location = 'http://216.224.161.207/nalocollector/login.php';
	});
});
